#coding=utf-8
#线程同步机制
#http://yoyzhou.github.io/blog/2013/02/28/python-threads-synchronization-locks/