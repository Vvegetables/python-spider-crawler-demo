#coding=utf-8
from education_crawler import create_table, EducationNews, get_session, engine


if __name__ == '__main__':
    create_table()
#     _session = get_session()
#     print _session
#     print 'success'
#     our_user = _session.query(EducationNews).filter_by(title='ed').first()
#     print our_user
    