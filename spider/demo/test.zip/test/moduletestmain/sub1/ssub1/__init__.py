#utf-8
from moduletestmain.sub1 import sub1
def ssub1():
    sub1()
    print 'ssub1'