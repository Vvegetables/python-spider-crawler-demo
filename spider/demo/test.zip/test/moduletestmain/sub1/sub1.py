#coding=utf-8

def sub1():
    print 'sub1'