#coding=utf-8
import moduletestmain.sub1,moduletestmain.sub2
def sub2():
    print 'sub2'